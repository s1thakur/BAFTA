-- MySQL dump 10.13  Distrib 5.7.17, for macos10.12 (x86_64)
--
-- Host: 127.0.0.1    Database: BAFTA_OLTP
-- ------------------------------------------------------
-- Server version	5.7.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `phone_number` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `payment_details` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,'James','Butt','504-621-8927','jbutt@gmail.com','1989-01-06','Visa'),(2,'Josephine','Darakjy','810-292-9388','josephine_darakjy@darakjy.org','1989-03-08','Master Card'),(3,'Art','Venere','856-636-8749','art@venere.org','1989-05-08','Master Card'),(4,'Lenna','Paprocki','907-385-4412','lpaprocki@hotmail.com','1989-07-08','Master Card'),(5,'Donette','Foller','513-570-1893','donette.foller@cox.net','1989-09-07','Visa'),(6,'Simona','Morasca','419-503-2484','simona@morasca.com','1989-11-07','Visa'),(7,'Mitsue','Tollner','773-573-6914','mitsue_tollner@yahoo.com','1990-01-07','Visa'),(8,'Leota','Dilliard','408-752-3500','leota@hotmail.com','1990-03-09','Visa'),(9,'Sage','Wieser','605-414-2147','sage_wieser@cox.net','1990-05-09','American Express'),(10,'Kris','Marrier','410-655-8723','kris@gmail.com','1990-07-09','American Express'),(11,'Minna','Amigon','215-874-1229','minna_amigon@yahoo.com','1990-09-08','Google Pay'),(12,'Abel','Maclead','631-335-3414','amaclead@gmail.com','1990-11-08','Google Pay'),(13,'Kiley','Caldarera','310-498-5651','kiley.caldarera@aol.com','1991-01-08','Google Pay'),(14,'Graciela','Ruta','440-780-8425','gruta@cox.net','1991-03-10','Visa'),(15,'Cammy','Albares','956-537-6195','calbares@gmail.com','1991-05-10','Master Card'),(16,'Mattie','Poquette','602-277-4385','mattie@aol.com','1991-07-10','Master Card'),(17,'Meaghan','Garufi','931-313-9635','meaghan@hotmail.com','1991-09-09','Visa'),(18,'Gladys','Rim','414-661-9598','gladys.rim@rim.org','1991-11-09','American Express'),(19,'Yuki','Whobrey','313-288-7937','yuki_whobrey@aol.com','1992-01-09','Google Pay'),(20,'Fletcher','Flosi','815-828-2147','fletcher.flosi@yahoo.com','1992-03-10','Google Pay'),(21,'Bette','Nicka','610-545-3615','bette_nicka@cox.net','1992-05-10','Visa'),(22,'Veronika','Inouye','408-540-1785','vinouye@aol.com','1992-07-10','Master Card'),(23,'Willard','Kolmetz','972-303-9197','willard@hotmail.com','1992-09-09','American Express'),(24,'Maryann','Royster','518-966-7987','mroyster@royster.com','1992-11-09','Master Card'),(25,'Alisha','Slusarski','732-658-3154','alisha@slusarski.com','1993-01-09','Visa'),(26,'Allene','Iturbide','715-662-6764','allene_iturbide@cox.net','1993-03-11','Google Pay'),(27,'Chanel','Caudy','913-388-2079','chanel.caudy@caudy.org','1993-05-11','Visa'),(28,'Ezekiel','Chui','410-669-1642','ezekiel@chui.com','1993-07-11','Visa'),(29,'Willow','Kusko','212-582-4976','wkusko@yahoo.com','1993-09-10','Google Pay'),(30,'Bernardo','Figeroa','936-336-3951','bfigeroa@aol.com','1993-11-10','American Express'),(31,'Ammie','Corrio','614-801-9788','ammie@corrio.com','1994-01-10','Master Card'),(32,'Francine','Vocelka','505-977-3911','francine_vocelka@vocelka.com','1994-03-12','Master Card'),(33,'Ernie','Stenseth','201-709-6245','ernie_stenseth@aol.com','1994-05-12','Master Card'),(34,'Albina','Glick','732-924-7882','albina@glick.com','1994-07-12','American Express'),(35,'Alishia','Sergi','212-860-1579','asergi@gmail.com','1994-09-11','Visa'),(36,'Solange','Shinko','504-979-9175','solange@shinko.com','1994-11-11','Master Card'),(37,'Jose','Stockham','212-675-8570','jose@yahoo.com','1995-01-11','Master Card'),(38,'Rozella','Ostrosky','805-832-6163','rozella.ostrosky@ostrosky.com','1995-03-13','Master Card'),(39,'Valentine','Gillian','210-812-9597','valentine_gillian@gmail.com','1995-05-13','Visa'),(40,'Kati','Rulapaugh','785-463-7829','kati.rulapaugh@hotmail.com','1995-07-13','Visa'),(41,'Youlanda','Schemmer','541-548-8197','youlanda@aol.com','1995-09-12','Visa'),(42,'Dyan','Oldroyd','913-413-4604','doldroyd@aol.com','1995-11-12','Visa'),(43,'Roxane','Campain','907-231-4722','roxane@hotmail.com','1996-01-12','American Express'),(44,'Lavera','Perin','305-606-7291','lperin@perin.org','1996-03-13','American Express'),(45,'Erick','Ferencz','907-741-1044','erick.ferencz@aol.com','1996-05-13','Google Pay'),(46,'Fatima','Saylors','952-768-2416','fsaylors@saylors.org','1996-07-13','Google Pay'),(47,'Jina','Briddick','617-399-5124','jina_briddick@briddick.com','1996-09-12','Google Pay'),(48,'Kanisha','Waycott','323-453-2780','kanisha_waycott@yahoo.com','1996-11-12','Visa'),(49,'Emerson','Bowley','608-336-7444','emerson.bowley@bowley.org','1997-01-12','Master Card'),(50,'Blair','Malet','215-907-9111','bmalet@yahoo.com','1997-03-14','Master Card'),(51,'Brock','Bolognia','212-402-9216','bbolognia@yahoo.com','1997-05-14','Visa'),(52,'Lorrie','Nestle','931-875-6644','lnestle@hotmail.com','1997-07-14','American Express'),(53,'Sabra','Uyetake','803-925-5213','sabra@uyetake.org','1997-09-13','Google Pay'),(54,'Marjory','Mastella','610-814-5533','mmastella@mastella.com','1997-11-13','Google Pay'),(55,'Karl','Klonowski','908-877-6135','karl_klonowski@yahoo.com','1998-01-13','Visa'),(56,'Tonette','Wenner','516-968-6051','twenner@aol.com','1998-03-15','Master Card'),(57,'Amber','Monarrez','215-934-8655','amber_monarrez@monarrez.org','1998-05-15','American Express'),(58,'Shenika','Seewald','818-423-4007','shenika@gmail.com','1998-07-15','Master Card'),(59,'Delmy','Ahle','401-458-2547','delmy.ahle@hotmail.com','1998-09-14','Visa'),(60,'Deeanna','Juhas','215-211-9589','deeanna_juhas@gmail.com','1998-11-14','Google Pay'),(61,'Blondell','Pugh','401-960-8259','bpugh@aol.com','1999-01-14','Visa'),(62,'Jamal','Vanausdal','732-234-1546','jamal@vanausdal.org','1999-03-16','Visa'),(63,'Cecily','Hollack','512-486-3817','cecily@hollack.org','1999-05-16','Google Pay'),(64,'Carmelina','Lindall','303-724-7371','carmelina_lindall@lindall.com','1999-07-16','American Express'),(65,'Maurine','Yglesias','414-748-1374','maurine_yglesias@yglesias.com','1999-09-15','Master Card'),(66,'Tawna','Buvens','212-674-9610','tawna@gmail.com','1999-11-15','Master Card'),(67,'Penney','Weight','907-797-9628','penney_weight@aol.com','2000-01-15','Master Card'),(68,'Elly','Morocco','814-393-5571','elly_morocco@gmail.com','2000-03-16','American Express'),(69,'Ilene','Eroman','410-914-9018','ilene.eroman@hotmail.com','2000-05-16','Visa'),(70,'Vallie','Mondella','208-862-5339','vmondella@mondella.com','2000-07-16','Master Card'),(71,'Kallie','Blackwood','415-315-2761','kallie.blackwood@gmail.com','2000-09-15','Master Card'),(72,'Johnetta','Abdallah','919-225-9345','johnetta_abdallah@aol.com','2000-11-15','Master Card'),(73,'Bobbye','Rhym','650-528-5783','brhym@rhym.com','2001-01-15','Visa'),(74,'Micaela','Rhymes','925-647-3298','micaela_rhymes@gmail.com','2001-03-17','Visa'),(75,'Tamar','Hoogland','740-343-8575','tamar@hotmail.com','2001-05-17','Visa'),(76,'Moon','Parlato','585-866-8313','moon@yahoo.com','2001-07-17','Visa'),(77,'Laurel','Reitler','410-520-4832','laurel_reitler@reitler.com','2001-09-16','American Express'),(78,'Delisa','Crupi','973-354-2040','delisa.crupi@crupi.com','2001-11-16','American Express'),(79,'Viva','Toelkes','773-446-5569','viva.toelkes@gmail.com','2002-01-16','Google Pay'),(80,'Elza','Lipke','973-927-3447','elza@yahoo.com','2002-03-18','Google Pay'),(81,'Devorah','Chickering','505-975-8559','devorah@hotmail.com','2002-05-18','Google Pay'),(82,'Timothy','Mulqueen','718-332-6527','timothy_mulqueen@mulqueen.org','2002-07-18','Visa'),(83,'Arlette','Honeywell','904-775-4480','ahoneywell@honeywell.com','2002-09-17','Master Card'),(84,'Dominque','Dickerson','510-993-3758','dominque.dickerson@dickerson.org','2002-11-17','Master Card'),(85,'Lettie','Isenhower','216-657-7668','lettie_isenhower@yahoo.com','2003-01-17','Visa'),(86,'Myra','Munns','817-914-7518','mmunns@cox.net','2003-03-19','American Express'),(87,'Stephaine','Barfield','310-774-7643','stephaine@barfield.com','2003-05-19','Google Pay'),(88,'Lai','Gato','847-728-7286','lai.gato@gato.org','2003-07-19','Google Pay'),(89,'Stephen','Emigh','330-537-5358','stephen_emigh@hotmail.com','2003-09-18','Visa'),(90,'Tyra','Shields','215-255-1641','tshields@gmail.com','2003-11-18','Master Card'),(91,'Tammara','Wardrip','650-803-1936','twardrip@cox.net','2004-01-18','American Express'),(92,'Cory','Gibes','626-572-1096','cory.gibes@gmail.com','2004-03-19','Master Card'),(93,'Danica','Bruschke','254-782-8569','danica_bruschke@gmail.com','2004-05-19','Visa'),(94,'Wilda','Giguere','907-870-5536','wilda@cox.net','2004-07-19','Google Pay'),(95,'Elvera','Benimadho','408-703-8505','elvera.benimadho@cox.net','2004-09-18','Visa'),(96,'Carma','Vanheusen','510-503-7169','carma@cox.net','2004-11-18','Visa'),(97,'Malinda','Hochard','317-722-5066','malinda.hochard@yahoo.com','2005-01-18','Google Pay'),(98,'Natalie','Fern','307-704-8713','natalie.fern@hotmail.com','2005-03-20','American Express'),(99,'Lisha','Centini','703-235-3937','lisha@centini.org','2005-05-20','Master Card'),(100,'Arlene','Klusman','504-710-5840','arlene_klusman@gmail.com','2005-07-20','Master Card');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_location`
--

DROP TABLE IF EXISTS `customer_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_location` (
  `location_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  PRIMARY KEY (`location_id`,`customer_id`),
  KEY `fk_Location_has_Customer_Customer1_idx` (`customer_id`),
  KEY `fk_Location_has_Customer_Location1_idx` (`location_id`),
  CONSTRAINT `fk_Location_has_Customer_Customer1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Location_has_Customer_Location1` FOREIGN KEY (`location_id`) REFERENCES `location` (`location_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_location`
--

LOCK TABLES `customer_location` WRITE;
/*!40000 ALTER TABLE `customer_location` DISABLE KEYS */;
INSERT INTO `customer_location` VALUES (1,1),(2,2),(3,3),(4,4),(5,5),(6,6),(7,7),(8,8),(9,9),(10,10),(11,11),(12,12),(13,13),(14,14),(15,15),(16,16),(17,17),(18,18),(19,19),(20,20),(21,21),(22,22),(23,23),(24,24),(25,25),(26,26),(27,27),(28,28),(29,29),(30,30),(31,31),(32,32),(33,33),(34,34),(35,35),(36,36),(37,37),(38,38),(39,39),(40,40),(41,41),(42,42),(43,43),(44,44),(45,45),(46,46),(47,47),(48,48),(49,49),(50,50),(51,51),(52,52),(53,53),(54,54),(55,55),(56,56),(57,57),(58,58),(59,59),(60,60),(61,61),(62,62),(63,63),(64,64),(65,65),(66,66),(67,67),(68,68),(69,69),(70,70),(71,71),(72,72),(73,73),(74,74),(75,75),(76,76),(77,77),(78,78),(79,79),(80,80),(81,81),(82,82),(83,83),(84,84),(85,85),(86,86),(87,87),(88,88),(89,89),(90,90),(91,91),(92,92),(93,93),(94,94),(95,95),(96,96),(97,97),(98,98),(99,99),(100,100);
/*!40000 ALTER TABLE `customer_location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `location` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `zip_code` int(11) DEFAULT NULL,
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=127 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location`
--

LOCK TABLES `location` WRITE;
/*!40000 ALTER TABLE `location` DISABLE KEYS */;
INSERT INTO `location` VALUES (1,95050),(2,95014),(3,95054),(4,94087),(5,94041),(6,95110),(7,95050),(8,95050),(9,95050),(10,95014),(11,95014),(12,94087),(13,94087),(14,94087),(15,94087),(16,94041),(17,94041),(18,95110),(19,94041),(20,95110),(21,95110),(22,95050),(23,95014),(24,95054),(25,94087),(26,94041),(27,95110),(28,95050),(29,95050),(30,95050),(31,95014),(32,95014),(33,94087),(34,94087),(35,94087),(36,94087),(37,94041),(38,94041),(39,95110),(40,94041),(41,95110),(42,95110),(43,95050),(44,95014),(45,95054),(46,94087),(47,94041),(48,95110),(49,95050),(50,95050),(51,95050),(52,95014),(53,95014),(54,94087),(55,94087),(56,94087),(57,94087),(58,94041),(59,94041),(60,95110),(61,94041),(62,95110),(63,95110),(64,94087),(65,94087),(66,94041),(67,94041),(68,95110),(69,94041),(70,94087),(71,94087),(72,94041),(73,94041),(74,95110),(75,94041),(76,95054),(77,95054),(78,94041),(79,95110),(80,94041),(81,95054),(82,94041),(83,95110),(84,94041),(85,95054),(86,95054),(87,94087),(88,94041),(89,95110),(90,95054),(91,94087),(92,94041),(93,95110),(94,94087),(95,94087),(96,94087),(97,94087),(98,94041),(99,94041),(100,94087),(101,94087),(102,94087),(103,94087),(104,94041),(105,94041),(106,95054),(107,94087),(108,94041),(109,95110),(110,95050),(111,95050),(112,95054),(113,94087),(114,94041),(115,95110),(116,95050),(117,95050),(118,95050),(119,95014),(120,95054),(121,94087),(122,94041),(123,95110),(124,95050),(125,94041),(126,95110);
/*!40000 ALTER TABLE `location` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-03 14:58:10
