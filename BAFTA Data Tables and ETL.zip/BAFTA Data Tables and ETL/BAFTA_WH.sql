CREATE DATABASE  IF NOT EXISTS `BAFTA_WH` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `BAFTA_WH`;
-- MySQL dump 10.13  Distrib 5.7.17, for macos10.12 (x86_64)
--
-- Host: 127.0.0.1    Database: BAFTA_WH
-- ------------------------------------------------------
-- Server version	5.7.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer_dim`
--

DROP TABLE IF EXISTS `customer_dim`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_dim` (
  `customer_key` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `first_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `phone_number` varchar(45) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `favorite_truck_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`customer_key`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_dim`
--

LOCK TABLES `customer_dim` WRITE;
/*!40000 ALTER TABLE `customer_dim` DISABLE KEYS */;
INSERT INTO `customer_dim` VALUES (1,1,'James','Butt','jbutt@gmail.com','504-621-8927','1989-01-06',7),(2,2,'Josephine','Darakjy','josephine_darakjy@darakjy.org','810-292-9388','1989-03-08',1),(3,3,'Art','Venere','art@venere.org','856-636-8749','1989-05-08',2),(4,4,'Lenna','Paprocki','lpaprocki@hotmail.com','907-385-4412','1989-07-08',3),(5,5,'Donette','Foller','donette.foller@cox.net','513-570-1893','1989-09-07',4),(6,6,'Simona','Morasca','simona@morasca.com','419-503-2484','1989-11-07',5),(7,7,'Mitsue','Tollner','mitsue_tollner@yahoo.com','773-573-6914','1990-01-07',6),(8,8,'Leota','Dilliard','leota@hotmail.com','408-752-3500','1990-03-09',7),(9,9,'Sage','Wieser','sage_wieser@cox.net','605-414-2147','1990-05-09',8),(10,10,'Kris','Marrier','kris@gmail.com','410-655-8723','1990-07-09',9),(11,11,'Minna','Amigon','minna_amigon@yahoo.com','215-874-1229','1990-09-08',10),(12,12,'Abel','Maclead','amaclead@gmail.com','631-335-3414','1990-11-08',11),(13,13,'Kiley','Caldarera','kiley.caldarera@aol.com','310-498-5651','1991-01-08',12),(14,14,'Graciela','Ruta','gruta@cox.net','440-780-8425','1991-03-10',7),(15,15,'Cammy','Albares','calbares@gmail.com','956-537-6195','1991-05-10',1),(16,16,'Mattie','Poquette','mattie@aol.com','602-277-4385','1991-07-10',2),(17,17,'Meaghan','Garufi','meaghan@hotmail.com','931-313-9635','1991-09-09',3),(18,18,'Gladys','Rim','gladys.rim@rim.org','414-661-9598','1991-11-09',4),(19,19,'Yuki','Whobrey','yuki_whobrey@aol.com','313-288-7937','1992-01-09',5),(20,20,'Fletcher','Flosi','fletcher.flosi@yahoo.com','815-828-2147','1992-03-10',6),(21,21,'Bette','Nicka','bette_nicka@cox.net','610-545-3615','1992-05-10',7),(22,22,'Veronika','Inouye','vinouye@aol.com','408-540-1785','1992-07-10',8),(23,23,'Willard','Kolmetz','willard@hotmail.com','972-303-9197','1992-09-09',9),(24,24,'Maryann','Royster','mroyster@royster.com','518-966-7987','1992-11-09',10),(25,25,'Alisha','Slusarski','alisha@slusarski.com','732-658-3154','1993-01-09',11),(26,26,'Allene','Iturbide','allene_iturbide@cox.net','715-662-6764','1993-03-11',12),(27,27,'Chanel','Caudy','chanel.caudy@caudy.org','913-388-2079','1993-05-11',7),(28,28,'Ezekiel','Chui','ezekiel@chui.com','410-669-1642','1993-07-11',1),(29,29,'Willow','Kusko','wkusko@yahoo.com','212-582-4976','1993-09-10',2),(30,30,'Bernardo','Figeroa','bfigeroa@aol.com','936-336-3951','1993-11-10',3),(31,31,'Ammie','Corrio','ammie@corrio.com','614-801-9788','1994-01-10',4),(32,32,'Francine','Vocelka','francine_vocelka@vocelka.com','505-977-3911','1994-03-12',5),(33,33,'Ernie','Stenseth','ernie_stenseth@aol.com','201-709-6245','1994-05-12',6),(34,34,'Albina','Glick','albina@glick.com','732-924-7882','1994-07-12',7),(35,35,'Alishia','Sergi','asergi@gmail.com','212-860-1579','1994-09-11',8),(36,36,'Solange','Shinko','solange@shinko.com','504-979-9175','1994-11-11',9),(37,37,'Jose','Stockham','jose@yahoo.com','212-675-8570','1995-01-11',10),(38,38,'Rozella','Ostrosky','rozella.ostrosky@ostrosky.com','805-832-6163','1995-03-13',11),(39,39,'Valentine','Gillian','valentine_gillian@gmail.com','210-812-9597','1995-05-13',12),(40,40,'Kati','Rulapaugh','kati.rulapaugh@hotmail.com','785-463-7829','1995-07-13',7),(41,41,'Youlanda','Schemmer','youlanda@aol.com','541-548-8197','1995-09-12',1),(42,42,'Dyan','Oldroyd','doldroyd@aol.com','913-413-4604','1995-11-12',2),(43,43,'Roxane','Campain','roxane@hotmail.com','907-231-4722','1996-01-12',3),(44,44,'Lavera','Perin','lperin@perin.org','305-606-7291','1996-03-13',4),(45,45,'Erick','Ferencz','erick.ferencz@aol.com','907-741-1044','1996-05-13',5),(46,46,'Fatima','Saylors','fsaylors@saylors.org','952-768-2416','1996-07-13',6),(47,47,'Jina','Briddick','jina_briddick@briddick.com','617-399-5124','1996-09-12',7),(48,48,'Kanisha','Waycott','kanisha_waycott@yahoo.com','323-453-2780','1996-11-12',8),(49,49,'Emerson','Bowley','emerson.bowley@bowley.org','608-336-7444','1997-01-12',9),(50,50,'Blair','Malet','bmalet@yahoo.com','215-907-9111','1997-03-14',10),(51,51,'Brock','Bolognia','bbolognia@yahoo.com','212-402-9216','1997-05-14',11),(52,52,'Lorrie','Nestle','lnestle@hotmail.com','931-875-6644','1997-07-14',12),(53,53,'Sabra','Uyetake','sabra@uyetake.org','803-925-5213','1997-09-13',7),(54,54,'Marjory','Mastella','mmastella@mastella.com','610-814-5533','1997-11-13',1),(55,55,'Karl','Klonowski','karl_klonowski@yahoo.com','908-877-6135','1998-01-13',2),(56,56,'Tonette','Wenner','twenner@aol.com','516-968-6051','1998-03-15',3),(57,57,'Amber','Monarrez','amber_monarrez@monarrez.org','215-934-8655','1998-05-15',4),(58,58,'Shenika','Seewald','shenika@gmail.com','818-423-4007','1998-07-15',5),(59,59,'Delmy','Ahle','delmy.ahle@hotmail.com','401-458-2547','1998-09-14',6),(60,60,'Deeanna','Juhas','deeanna_juhas@gmail.com','215-211-9589','1998-11-14',7),(61,61,'Blondell','Pugh','bpugh@aol.com','401-960-8259','1999-01-14',8),(62,62,'Jamal','Vanausdal','jamal@vanausdal.org','732-234-1546','1999-03-16',9),(63,63,'Cecily','Hollack','cecily@hollack.org','512-486-3817','1999-05-16',10),(64,64,'Carmelina','Lindall','carmelina_lindall@lindall.com','303-724-7371','1999-07-16',11),(65,65,'Maurine','Yglesias','maurine_yglesias@yglesias.com','414-748-1374','1999-09-15',12),(66,66,'Tawna','Buvens','tawna@gmail.com','212-674-9610','1999-11-15',7),(67,67,'Penney','Weight','penney_weight@aol.com','907-797-9628','2000-01-15',1),(68,68,'Elly','Morocco','elly_morocco@gmail.com','814-393-5571','2000-03-16',2),(69,69,'Ilene','Eroman','ilene.eroman@hotmail.com','410-914-9018','2000-05-16',3),(70,70,'Vallie','Mondella','vmondella@mondella.com','208-862-5339','2000-07-16',4),(71,71,'Kallie','Blackwood','kallie.blackwood@gmail.com','415-315-2761','2000-09-15',5),(72,72,'Johnetta','Abdallah','johnetta_abdallah@aol.com','919-225-9345','2000-11-15',6),(73,73,'Bobbye','Rhym','brhym@rhym.com','650-528-5783','2001-01-15',7),(74,74,'Micaela','Rhymes','micaela_rhymes@gmail.com','925-647-3298','2001-03-17',8),(75,75,'Tamar','Hoogland','tamar@hotmail.com','740-343-8575','2001-05-17',9),(76,76,'Moon','Parlato','moon@yahoo.com','585-866-8313','2001-07-17',10),(77,77,'Laurel','Reitler','laurel_reitler@reitler.com','410-520-4832','2001-09-16',11),(78,78,'Delisa','Crupi','delisa.crupi@crupi.com','973-354-2040','2001-11-16',12),(79,79,'Viva','Toelkes','viva.toelkes@gmail.com','773-446-5569','2002-01-16',7),(80,80,'Elza','Lipke','elza@yahoo.com','973-927-3447','2002-03-18',1),(81,81,'Devorah','Chickering','devorah@hotmail.com','505-975-8559','2002-05-18',2),(82,82,'Timothy','Mulqueen','timothy_mulqueen@mulqueen.org','718-332-6527','2002-07-18',3),(83,83,'Arlette','Honeywell','ahoneywell@honeywell.com','904-775-4480','2002-09-17',4),(84,84,'Dominque','Dickerson','dominque.dickerson@dickerson.org','510-993-3758','2002-11-17',5),(85,85,'Lettie','Isenhower','lettie_isenhower@yahoo.com','216-657-7668','2003-01-17',6),(86,86,'Myra','Munns','mmunns@cox.net','817-914-7518','2003-03-19',7),(87,87,'Stephaine','Barfield','stephaine@barfield.com','310-774-7643','2003-05-19',8),(88,88,'Lai','Gato','lai.gato@gato.org','847-728-7286','2003-07-19',9),(89,89,'Stephen','Emigh','stephen_emigh@hotmail.com','330-537-5358','2003-09-18',10),(90,90,'Tyra','Shields','tshields@gmail.com','215-255-1641','2003-11-18',11),(91,91,'Tammara','Wardrip','twardrip@cox.net','650-803-1936','2004-01-18',12),(92,92,'Cory','Gibes','cory.gibes@gmail.com','626-572-1096','2004-03-19',7),(93,93,'Danica','Bruschke','danica_bruschke@gmail.com','254-782-8569','2004-05-19',1),(94,94,'Wilda','Giguere','wilda@cox.net','907-870-5536','2004-07-19',2),(95,95,'Elvera','Benimadho','elvera.benimadho@cox.net','408-703-8505','2004-09-18',3),(96,96,'Carma','Vanheusen','carma@cox.net','510-503-7169','2004-11-18',4),(97,97,'Malinda','Hochard','malinda.hochard@yahoo.com','317-722-5066','2005-01-18',5),(98,98,'Natalie','Fern','natalie.fern@hotmail.com','307-704-8713','2005-03-20',6),(99,99,'Lisha','Centini','lisha@centini.org','703-235-3937','2005-05-20',7),(100,100,'Arlene','Klusman','arlene_klusman@gmail.com','504-710-5840','2005-07-20',8);
/*!40000 ALTER TABLE `customer_dim` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_orders_fact`
--

DROP TABLE IF EXISTS `customer_orders_fact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_orders_fact` (
  `order_id` int(11) NOT NULL,
  `order_date` datetime DEFAULT NULL,
  `total_cost` float DEFAULT NULL,
  `customer_key` int(11) NOT NULL,
  `truck_key` int(11) NOT NULL,
  `customer_location_key` int(11) NOT NULL,
  `truck_location_key` int(11) NOT NULL,
  `dish_key` int(11) NOT NULL,
  PRIMARY KEY (`order_id`,`truck_location_key`,`customer_location_key`,`truck_key`,`customer_key`,`dish_key`),
  KEY `fk_Customer_Orders_Fact_Customer_Dim2_idx` (`customer_key`),
  KEY `fk_Customer_Orders_Fact_Food_Truck_Dim1_idx` (`truck_key`),
  KEY `fk_Customer_Orders_Fact_location_dim1_idx` (`customer_location_key`),
  KEY `fk_Customer_Orders_Fact_location_dim2_idx` (`truck_location_key`),
  KEY `fk_customer_orders_fact_dish_dim1_idx` (`dish_key`),
  CONSTRAINT `fk_Customer_Orders_Fact_Customer_Dim2` FOREIGN KEY (`customer_key`) REFERENCES `customer_dim` (`customer_key`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Customer_Orders_Fact_Food_Truck_Dim1` FOREIGN KEY (`truck_key`) REFERENCES `food_truck_dim` (`truck_key`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Customer_Orders_Fact_location_dim1` FOREIGN KEY (`customer_location_key`) REFERENCES `location_dim` (`location_key`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Customer_Orders_Fact_location_dim2` FOREIGN KEY (`truck_location_key`) REFERENCES `location_dim` (`location_key`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_customer_orders_fact_dish_dim1` FOREIGN KEY (`dish_key`) REFERENCES `dish_dim` (`dish_key`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_orders_fact`
--

LOCK TABLES `customer_orders_fact` WRITE;
/*!40000 ALTER TABLE `customer_orders_fact` DISABLE KEYS */;
INSERT INTO `customer_orders_fact` VALUES (12460,'2018-05-23 12:03:00',7,92,5,92,115,102),(12461,'2018-05-23 12:03:00',3,8,5,8,115,103),(12462,'2018-05-23 12:03:00',3,84,5,84,115,104),(12463,'2018-05-23 12:03:00',2,88,5,88,115,502),(12464,'2018-05-23 12:03:00',4,26,7,26,123,303),(12465,'2018-05-23 12:03:00',4,62,7,62,123,304),(12466,'2018-05-23 12:03:00',18,70,12,70,122,409),(12467,'2018-05-23 12:03:00',14,82,12,82,122,503),(12468,'2018-05-23 12:03:00',3,62,5,62,115,107),(12469,'2018-05-23 12:03:00',3,31,5,31,115,108),(12470,'2018-05-23 12:03:00',2,73,5,73,115,501),(12471,'2018-05-23 12:03:00',7,51,4,51,125,309),(12472,'2018-05-23 12:15:00',7,37,4,37,125,310),(12473,'2018-05-23 12:15:00',2,5,4,5,125,502),(12474,'2018-05-23 12:15:00',3,52,3,52,126,202),(12475,'2018-05-23 13:10:00',4,64,3,64,126,203),(12476,'2018-05-23 13:10:00',4,25,8,25,116,304),(12477,'2018-05-23 13:10:00',3,23,9,23,117,104),(12478,'2018-05-23 17:20:00',6,13,9,13,117,106),(12479,'2018-05-23 17:20:00',7,54,9,54,117,503),(12480,'2018-05-23 17:20:00',2,26,10,26,118,502),(12481,'2018-05-24 11:03:00',5,52,4,52,125,307),(12482,'2018-05-24 11:03:00',2,94,8,94,116,305),(12483,'2018-05-24 11:03:00',4,51,1,51,102,206),(12484,'2018-05-24 11:40:00',4,33,2,33,121,206),(12485,'2018-05-24 11:40:00',4,60,2,60,121,207),(12486,'2018-05-24 11:40:00',4,48,2,48,121,203),(12487,'2018-05-24 13:10:00',3,46,9,46,117,107),(12488,'2018-05-24 13:10:00',12,62,3,62,126,204),(12489,'2018-05-24 13:10:00',3,64,9,64,117,108),(12490,'2018-05-24 17:20:00',7,22,6,22,124,503),(12491,'2018-05-24 17:20:00',3,97,6,97,124,107),(12492,'2018-05-24 17:20:00',16,31,12,31,122,410),(12493,'2018-05-25 11:03:00',2,75,12,75,122,404),(12494,'2018-05-25 11:03:00',9,90,12,90,122,409),(12495,'2018-05-25 11:03:00',4,31,3,31,126,210),(12496,'2018-05-25 11:40:00',4,47,8,47,116,306),(12497,'2018-05-25 11:40:00',2,26,7,26,123,305),(12498,'2018-05-25 11:40:00',4,56,8,56,116,301),(12499,'2018-05-25 13:10:00',7,72,8,72,116,503),(12500,'2018-05-25 13:10:00',5,46,5,46,115,101),(12501,'2018-05-25 13:10:00',10,84,4,84,125,312),(12502,'2018-05-25 17:20:00',16,20,4,20,125,313),(12503,'2018-05-25 17:20:00',10,68,4,68,125,307),(12504,'2018-05-25 17:20:00',10,81,4,81,125,308),(12505,'2018-05-26 11:03:00',14,49,4,49,125,503),(12506,'2018-05-26 11:03:00',3,34,6,34,124,108),(12507,'2018-05-26 11:03:00',9,4,12,4,122,409),(12508,'2018-05-26 11:40:00',4,73,10,73,118,404),(12509,'2018-05-26 11:40:00',12,61,10,61,118,401),(12510,'2018-05-26 11:40:00',4,60,8,60,116,302),(12511,'2018-05-26 13:10:00',7,98,4,98,125,310),(12512,'2018-05-26 13:10:00',7,99,4,99,125,311),(12513,'2018-05-26 13:10:00',10,6,4,6,125,312),(12514,'2018-05-26 17:20:00',7,74,4,74,125,503),(12515,'2018-05-26 17:20:00',5,31,6,31,124,101),(12516,'2018-05-26 17:20:00',12,35,6,35,124,105),(12517,'2018-05-27 11:03:00',7,49,6,49,124,503),(12518,'2018-05-27 11:03:00',2,27,6,27,124,502),(12519,'2018-05-27 11:03:00',4,11,2,11,121,213),(12520,'2018-05-27 11:40:00',3,35,2,35,121,201),(12521,'2018-05-27 11:40:00',7,30,2,30,121,503),(12522,'2018-05-27 11:40:00',36,28,12,28,122,401),(12523,'2018-05-27 13:10:00',33,94,12,94,122,402),(12524,'2018-05-27 13:10:00',6,20,12,20,122,502),(12525,'2018-05-27 13:10:00',3,14,9,14,117,107),(12526,'2018-05-27 17:20:00',3,32,9,32,117,108),(12527,'2018-05-27 17:20:00',2,75,9,75,117,501),(12528,'2018-05-27 17:20:00',3,37,2,37,121,201),(12529,'2018-05-28 11:03:00',3,24,2,24,121,202),(12530,'2018-05-28 11:03:00',7,38,2,38,121,503),(12531,'2018-05-28 11:03:00',10,98,4,98,125,307),(12532,'2018-05-28 11:40:00',10,9,4,9,125,308),(12533,'2018-05-28 11:40:00',4,21,1,21,102,204),(12534,'2018-05-28 11:40:00',7,4,1,4,102,503),(12535,'2018-05-28 13:10:00',10,54,5,54,115,101),(12536,'2018-05-28 13:10:00',14,7,5,7,115,503),(12537,'2018-05-28 13:10:00',33,50,10,50,118,402),(12538,'2018-05-28 17:20:00',6,11,10,11,118,502),(12539,'2018-05-28 17:20:00',6,37,9,37,117,104),(12540,'2018-05-28 17:20:00',6,49,9,49,117,103),(12541,'2018-05-29 11:03:00',10,92,9,92,117,101),(12542,'2018-05-29 11:03:00',4,53,9,53,117,501),(12543,'2018-05-29 11:03:00',3,29,2,29,121,202),(12544,'2018-05-29 11:40:00',4,55,2,55,121,203),(12545,'2018-05-29 11:40:00',2,77,2,77,121,501),(12546,'2018-05-29 11:40:00',3,53,3,53,126,201),(12547,'2018-05-29 13:10:00',8,55,7,55,123,301),(12548,'2018-05-29 13:10:00',14,49,7,49,123,503),(12549,'2018-05-29 13:10:00',4,15,8,15,116,301),(12550,'2018-05-29 17:20:00',2,49,8,49,116,501),(12551,'2018-05-29 17:20:00',4,1,8,1,116,303),(12552,'2018-05-29 17:20:00',5,97,9,97,117,101),(12553,'2018-05-30 11:03:00',3,5,9,5,117,103),(12554,'2018-05-30 11:03:00',2,47,9,47,117,502),(12555,'2018-05-30 11:03:00',8,77,2,77,121,204),(12556,'2018-05-30 11:40:00',8,27,2,27,121,205),(12557,'2018-05-30 11:40:00',14,73,2,73,121,503),(12558,'2018-05-30 11:40:00',7,8,5,8,115,102),(12559,'2018-05-30 13:10:00',3,50,5,50,115,103),(12560,'2018-05-30 13:10:00',3,29,5,29,115,104),(12561,'2018-05-30 13:10:00',2,73,5,73,115,502),(12562,'2018-05-30 17:20:00',4,63,7,63,123,303),(12563,'2018-05-30 17:20:00',4,97,7,97,123,304),(12564,'2018-05-30 17:20:00',18,82,12,82,122,409),(12565,'2018-05-31 11:03:00',14,51,12,51,122,503),(12566,'2018-05-31 11:03:00',3,18,5,18,115,107),(12567,'2018-05-31 11:03:00',3,78,5,78,115,108),(12568,'2018-05-31 11:40:00',2,10,5,10,115,501),(12569,'2018-05-31 11:40:00',7,84,4,84,125,309),(12570,'2018-05-31 11:40:00',7,89,4,89,125,310),(12571,'2018-05-31 13:10:00',2,64,4,64,125,502),(12572,'2018-05-31 13:10:00',3,95,3,95,126,202),(12573,'2018-05-31 13:10:00',4,12,3,12,126,203),(12574,'2018-05-31 17:20:00',4,6,8,6,116,304),(12575,'2018-05-31 17:20:00',3,98,9,98,117,104),(12576,'2018-05-31 17:20:00',6,48,9,48,117,106),(12577,'2018-06-01 11:03:00',7,73,9,73,117,503),(12578,'2018-06-01 11:03:00',2,81,10,81,118,502),(12579,'2018-06-01 11:03:00',5,35,4,35,125,307),(12580,'2018-06-01 17:20:00',2,8,8,8,116,305),(12581,'2018-06-01 17:20:00',4,72,1,72,102,206),(12582,'2018-06-01 17:20:00',4,68,2,68,121,206),(12583,'2018-06-02 11:03:00',4,49,2,49,121,207),(12584,'2018-06-02 11:03:00',4,94,2,94,121,203),(12585,'2018-06-02 11:03:00',3,69,9,69,117,107),(12586,'2018-06-02 17:20:00',12,53,3,53,126,204),(12587,'2018-06-02 17:20:00',3,27,9,27,117,108),(12588,'2018-06-02 17:20:00',7,64,6,64,124,503),(12589,'2018-06-03 11:03:00',3,56,6,56,124,107),(12590,'2018-06-03 11:03:00',16,91,12,91,122,410),(12591,'2018-06-03 11:03:00',2,51,12,51,122,404),(12592,'2018-06-03 17:20:00',9,61,12,61,122,409),(12593,'2018-06-03 17:20:00',4,80,3,80,126,210),(12594,'2018-06-03 17:20:00',4,4,8,4,116,306),(12595,'2018-06-04 11:03:00',2,94,7,94,123,305),(12596,'2018-06-04 11:03:00',4,67,8,67,116,301),(12597,'2018-06-04 11:03:00',7,8,8,8,116,503),(12598,'2018-06-04 17:20:00',5,86,5,86,115,101),(12599,'2018-06-04 17:20:00',10,73,4,73,125,312),(12600,'2018-06-04 17:20:00',16,71,4,71,125,313),(12601,'2018-06-05 11:03:00',10,85,4,85,125,307),(12602,'2018-06-05 11:03:00',10,88,4,88,125,308),(12603,'2018-06-05 11:03:00',14,83,4,83,125,503),(12604,'2018-06-05 17:20:00',3,2,6,2,124,108),(12605,'2018-06-05 17:20:00',9,68,12,68,122,409),(12606,'2018-06-05 17:20:00',4,67,10,67,118,404);
/*!40000 ALTER TABLE `customer_orders_fact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dish_dim`
--

DROP TABLE IF EXISTS `dish_dim`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dish_dim` (
  `dish_key` int(11) NOT NULL,
  `dish_id` int(11) NOT NULL,
  `dish_name` varchar(45) NOT NULL,
  PRIMARY KEY (`dish_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dish_dim`
--

LOCK TABLES `dish_dim` WRITE;
/*!40000 ALTER TABLE `dish_dim` DISABLE KEYS */;
INSERT INTO `dish_dim` VALUES (101,101,'Hamburger'),(102,102,'Fish and Chips'),(103,103,'Grilled Cheese'),(104,104,'Hot Dog'),(105,105,'Ribs'),(106,106,'Bacon Burger'),(107,107,'Fries'),(108,108,'Sweet Potato Fries'),(201,201,'Taco - beef'),(202,202,'Taco - pork'),(203,203,'Taco - fish'),(204,204,'Taco - steak'),(205,205,'Burrito Steak'),(206,206,'Burrito Chicken'),(207,207,'Burrito Fish'),(210,210,'Carnitas'),(213,213,'Quesadilla - chicken'),(301,301,'Noodles - Chicken'),(302,302,'Beef Broccoli'),(303,303,'Pot Stickers'),(304,304,'Sweet and Sour Pork'),(305,305,'Fried Rice'),(306,306,'Pork fried rice'),(307,307,'Curry Katsu'),(308,308,'Chicken Katsu'),(309,309,'Poke Bowl'),(310,310,'Bulgogi'),(311,311,'Bulgogi Burrito'),(312,312,'Roast Duck'),(313,313,'Duck Burrito'),(401,401,'Butter Chicken'),(402,402,'Chicken tikka masala'),(403,403,'Plain Naan'),(404,404,'Butter Naan'),(405,405,'Garlic Naan'),(406,406,'Lachcha Parantha'),(407,407,'Chicken Biryani'),(408,408,'Mutton Biryani'),(409,409,'Punjabi Chhole'),(410,410,'Dal Makhani'),(411,411,'Sarson da saag'),(412,412,'Makki di roti'),(501,501,'Soda Drink'),(502,502,'Bottled Water'),(503,503,'Craft Beer');
/*!40000 ALTER TABLE `dish_dim` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `food_truck_dim`
--

DROP TABLE IF EXISTS `food_truck_dim`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `food_truck_dim` (
  `truck_key` int(11) NOT NULL AUTO_INCREMENT,
  `truck_id` int(11) NOT NULL,
  `truck_name` varchar(45) NOT NULL,
  `truck_type` varchar(45) DEFAULT NULL,
  `rating` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`truck_key`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `food_truck_dim`
--

LOCK TABLES `food_truck_dim` WRITE;
/*!40000 ALTER TABLE `food_truck_dim` DISABLE KEYS */;
INSERT INTO `food_truck_dim` VALUES (1,1,'El Tonayense','Mexican','3.6666666666666665'),(2,2,'Taco Guys','Mexican','6.4'),(3,3,'Tacos El Gordo','Mexican','9.0'),(4,4,'Ko Ja Kitchen','Korean-Japanese','8.466666666666667'),(5,5,'The Chairman','American','5.4'),(6,6,'J Shack','American','7.571428571428571'),(7,7,'Pluck','Chinese','8.0'),(8,8,'Fins on the Hoof','Chinese','9.0'),(9,9,'Mayo and Mustard','American','6.133333333333334'),(10,10,'Biryani house','Indian','6.6'),(11,12,'Curry up Now','Indian','5.666666666666667'),(12,12,'Curry up Now','Indian','5.666666666666667');
/*!40000 ALTER TABLE `food_truck_dim` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location_dim`
--

DROP TABLE IF EXISTS `location_dim`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `location_dim` (
  `location_key` int(11) NOT NULL AUTO_INCREMENT,
  `location_id` int(11) NOT NULL,
  `zip_code` int(11) DEFAULT NULL,
  PRIMARY KEY (`location_key`)
) ENGINE=InnoDB AUTO_INCREMENT=127 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location_dim`
--

LOCK TABLES `location_dim` WRITE;
/*!40000 ALTER TABLE `location_dim` DISABLE KEYS */;
INSERT INTO `location_dim` VALUES (1,1,95050),(2,2,95014),(3,3,95054),(4,4,94087),(5,5,94041),(6,6,95110),(7,7,95050),(8,8,95050),(9,9,95050),(10,10,95014),(11,11,95014),(12,12,94087),(13,13,94087),(14,14,94087),(15,15,94087),(16,16,94041),(17,17,94041),(18,18,95110),(19,19,94041),(20,20,95110),(21,21,95110),(22,22,95050),(23,23,95014),(24,24,95054),(25,25,94087),(26,26,94041),(27,27,95110),(28,28,95050),(29,29,95050),(30,30,95050),(31,31,95014),(32,32,95014),(33,33,94087),(34,34,94087),(35,35,94087),(36,36,94087),(37,37,94041),(38,38,94041),(39,39,95110),(40,40,94041),(41,41,95110),(42,42,95110),(43,43,95050),(44,44,95014),(45,45,95054),(46,46,94087),(47,47,94041),(48,48,95110),(49,49,95050),(50,50,95050),(51,51,95050),(52,52,95014),(53,53,95014),(54,54,94087),(55,55,94087),(56,56,94087),(57,57,94087),(58,58,94041),(59,59,94041),(60,60,95110),(61,61,94041),(62,62,95110),(63,63,95110),(64,64,94087),(65,65,94087),(66,66,94041),(67,67,94041),(68,68,95110),(69,69,94041),(70,70,94087),(71,71,94087),(72,72,94041),(73,73,94041),(74,74,95110),(75,75,94041),(76,76,95054),(77,77,95054),(78,78,94041),(79,79,95110),(80,80,94041),(81,81,95054),(82,82,94041),(83,83,95110),(84,84,94041),(85,85,95054),(86,86,95054),(87,87,94087),(88,88,94041),(89,89,95110),(90,90,95054),(91,91,94087),(92,92,94041),(93,93,95110),(94,94,94087),(95,95,94087),(96,96,94087),(97,97,94087),(98,98,94041),(99,99,94041),(100,100,94087),(101,101,94087),(102,102,94087),(103,103,94087),(104,104,94041),(105,105,94041),(106,106,95054),(107,107,94087),(108,108,94041),(109,109,95110),(110,110,95050),(111,111,95050),(112,112,95054),(113,113,94087),(114,114,94041),(115,115,95110),(116,116,95050),(117,117,95050),(118,118,95050),(119,119,95014),(120,120,95054),(121,121,94087),(122,122,94041),(123,123,95110),(124,124,95050),(125,125,94041),(126,126,95110);
/*!40000 ALTER TABLE `location_dim` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-05-23 22:29:45
