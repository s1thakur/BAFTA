CREATE DATABASE  IF NOT EXISTS `BAFTA_OLTP` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `BAFTA_OLTP`;
-- MySQL dump 10.13  Distrib 5.7.17, for macos10.12 (x86_64)
--
-- Host: 127.0.0.1    Database: BAFTA_OLTP
-- ------------------------------------------------------
-- Server version	5.7.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `phone_number` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `payment_details` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,'James','Butt','504-621-8927','jbutt@gmail.com','1989-01-06','Visa'),(2,'Josephine','Darakjy','810-292-9388','josephine_darakjy@darakjy.org','1989-03-08','Master Card'),(3,'Art','Venere','856-636-8749','art@venere.org','1989-05-08','Master Card'),(4,'Lenna','Paprocki','907-385-4412','lpaprocki@hotmail.com','1989-07-08','Master Card'),(5,'Donette','Foller','513-570-1893','donette.foller@cox.net','1989-09-07','Visa'),(6,'Simona','Morasca','419-503-2484','simona@morasca.com','1989-11-07','Visa'),(7,'Mitsue','Tollner','773-573-6914','mitsue_tollner@yahoo.com','1990-01-07','Visa'),(8,'Leota','Dilliard','408-752-3500','leota@hotmail.com','1990-03-09','Visa'),(9,'Sage','Wieser','605-414-2147','sage_wieser@cox.net','1990-05-09','American Express'),(10,'Kris','Marrier','410-655-8723','kris@gmail.com','1990-07-09','American Express'),(11,'Minna','Amigon','215-874-1229','minna_amigon@yahoo.com','1990-09-08','Google Pay'),(12,'Abel','Maclead','631-335-3414','amaclead@gmail.com','1990-11-08','Google Pay'),(13,'Kiley','Caldarera','310-498-5651','kiley.caldarera@aol.com','1991-01-08','Google Pay'),(14,'Graciela','Ruta','440-780-8425','gruta@cox.net','1991-03-10','Visa'),(15,'Cammy','Albares','956-537-6195','calbares@gmail.com','1991-05-10','Master Card'),(16,'Mattie','Poquette','602-277-4385','mattie@aol.com','1991-07-10','Master Card'),(17,'Meaghan','Garufi','931-313-9635','meaghan@hotmail.com','1991-09-09','Visa'),(18,'Gladys','Rim','414-661-9598','gladys.rim@rim.org','1991-11-09','American Express'),(19,'Yuki','Whobrey','313-288-7937','yuki_whobrey@aol.com','1992-01-09','Google Pay'),(20,'Fletcher','Flosi','815-828-2147','fletcher.flosi@yahoo.com','1992-03-10','Google Pay'),(21,'Bette','Nicka','610-545-3615','bette_nicka@cox.net','1992-05-10','Visa'),(22,'Veronika','Inouye','408-540-1785','vinouye@aol.com','1992-07-10','Master Card'),(23,'Willard','Kolmetz','972-303-9197','willard@hotmail.com','1992-09-09','American Express'),(24,'Maryann','Royster','518-966-7987','mroyster@royster.com','1992-11-09','Master Card'),(25,'Alisha','Slusarski','732-658-3154','alisha@slusarski.com','1993-01-09','Visa'),(26,'Allene','Iturbide','715-662-6764','allene_iturbide@cox.net','1993-03-11','Google Pay'),(27,'Chanel','Caudy','913-388-2079','chanel.caudy@caudy.org','1993-05-11','Visa'),(28,'Ezekiel','Chui','410-669-1642','ezekiel@chui.com','1993-07-11','Visa'),(29,'Willow','Kusko','212-582-4976','wkusko@yahoo.com','1993-09-10','Google Pay'),(30,'Bernardo','Figeroa','936-336-3951','bfigeroa@aol.com','1993-11-10','American Express'),(31,'Ammie','Corrio','614-801-9788','ammie@corrio.com','1994-01-10','Master Card'),(32,'Francine','Vocelka','505-977-3911','francine_vocelka@vocelka.com','1994-03-12','Master Card'),(33,'Ernie','Stenseth','201-709-6245','ernie_stenseth@aol.com','1994-05-12','Master Card'),(34,'Albina','Glick','732-924-7882','albina@glick.com','1994-07-12','American Express'),(35,'Alishia','Sergi','212-860-1579','asergi@gmail.com','1994-09-11','Visa'),(36,'Solange','Shinko','504-979-9175','solange@shinko.com','1994-11-11','Master Card'),(37,'Jose','Stockham','212-675-8570','jose@yahoo.com','1995-01-11','Master Card'),(38,'Rozella','Ostrosky','805-832-6163','rozella.ostrosky@ostrosky.com','1995-03-13','Master Card'),(39,'Valentine','Gillian','210-812-9597','valentine_gillian@gmail.com','1995-05-13','Visa'),(40,'Kati','Rulapaugh','785-463-7829','kati.rulapaugh@hotmail.com','1995-07-13','Visa'),(41,'Youlanda','Schemmer','541-548-8197','youlanda@aol.com','1995-09-12','Visa'),(42,'Dyan','Oldroyd','913-413-4604','doldroyd@aol.com','1995-11-12','Visa'),(43,'Roxane','Campain','907-231-4722','roxane@hotmail.com','1996-01-12','American Express'),(44,'Lavera','Perin','305-606-7291','lperin@perin.org','1996-03-13','American Express'),(45,'Erick','Ferencz','907-741-1044','erick.ferencz@aol.com','1996-05-13','Google Pay'),(46,'Fatima','Saylors','952-768-2416','fsaylors@saylors.org','1996-07-13','Google Pay'),(47,'Jina','Briddick','617-399-5124','jina_briddick@briddick.com','1996-09-12','Google Pay'),(48,'Kanisha','Waycott','323-453-2780','kanisha_waycott@yahoo.com','1996-11-12','Visa'),(49,'Emerson','Bowley','608-336-7444','emerson.bowley@bowley.org','1997-01-12','Master Card'),(50,'Blair','Malet','215-907-9111','bmalet@yahoo.com','1997-03-14','Master Card'),(51,'Brock','Bolognia','212-402-9216','bbolognia@yahoo.com','1997-05-14','Visa'),(52,'Lorrie','Nestle','931-875-6644','lnestle@hotmail.com','1997-07-14','American Express'),(53,'Sabra','Uyetake','803-925-5213','sabra@uyetake.org','1997-09-13','Google Pay'),(54,'Marjory','Mastella','610-814-5533','mmastella@mastella.com','1997-11-13','Google Pay'),(55,'Karl','Klonowski','908-877-6135','karl_klonowski@yahoo.com','1998-01-13','Visa'),(56,'Tonette','Wenner','516-968-6051','twenner@aol.com','1998-03-15','Master Card'),(57,'Amber','Monarrez','215-934-8655','amber_monarrez@monarrez.org','1998-05-15','American Express'),(58,'Shenika','Seewald','818-423-4007','shenika@gmail.com','1998-07-15','Master Card'),(59,'Delmy','Ahle','401-458-2547','delmy.ahle@hotmail.com','1998-09-14','Visa'),(60,'Deeanna','Juhas','215-211-9589','deeanna_juhas@gmail.com','1998-11-14','Google Pay'),(61,'Blondell','Pugh','401-960-8259','bpugh@aol.com','1999-01-14','Visa'),(62,'Jamal','Vanausdal','732-234-1546','jamal@vanausdal.org','1999-03-16','Visa'),(63,'Cecily','Hollack','512-486-3817','cecily@hollack.org','1999-05-16','Google Pay'),(64,'Carmelina','Lindall','303-724-7371','carmelina_lindall@lindall.com','1999-07-16','American Express'),(65,'Maurine','Yglesias','414-748-1374','maurine_yglesias@yglesias.com','1999-09-15','Master Card'),(66,'Tawna','Buvens','212-674-9610','tawna@gmail.com','1999-11-15','Master Card'),(67,'Penney','Weight','907-797-9628','penney_weight@aol.com','2000-01-15','Master Card'),(68,'Elly','Morocco','814-393-5571','elly_morocco@gmail.com','2000-03-16','American Express'),(69,'Ilene','Eroman','410-914-9018','ilene.eroman@hotmail.com','2000-05-16','Visa'),(70,'Vallie','Mondella','208-862-5339','vmondella@mondella.com','2000-07-16','Master Card'),(71,'Kallie','Blackwood','415-315-2761','kallie.blackwood@gmail.com','2000-09-15','Master Card'),(72,'Johnetta','Abdallah','919-225-9345','johnetta_abdallah@aol.com','2000-11-15','Master Card'),(73,'Bobbye','Rhym','650-528-5783','brhym@rhym.com','2001-01-15','Visa'),(74,'Micaela','Rhymes','925-647-3298','micaela_rhymes@gmail.com','2001-03-17','Visa'),(75,'Tamar','Hoogland','740-343-8575','tamar@hotmail.com','2001-05-17','Visa'),(76,'Moon','Parlato','585-866-8313','moon@yahoo.com','2001-07-17','Visa'),(77,'Laurel','Reitler','410-520-4832','laurel_reitler@reitler.com','2001-09-16','American Express'),(78,'Delisa','Crupi','973-354-2040','delisa.crupi@crupi.com','2001-11-16','American Express'),(79,'Viva','Toelkes','773-446-5569','viva.toelkes@gmail.com','2002-01-16','Google Pay'),(80,'Elza','Lipke','973-927-3447','elza@yahoo.com','2002-03-18','Google Pay'),(81,'Devorah','Chickering','505-975-8559','devorah@hotmail.com','2002-05-18','Google Pay'),(82,'Timothy','Mulqueen','718-332-6527','timothy_mulqueen@mulqueen.org','2002-07-18','Visa'),(83,'Arlette','Honeywell','904-775-4480','ahoneywell@honeywell.com','2002-09-17','Master Card'),(84,'Dominque','Dickerson','510-993-3758','dominque.dickerson@dickerson.org','2002-11-17','Master Card'),(85,'Lettie','Isenhower','216-657-7668','lettie_isenhower@yahoo.com','2003-01-17','Visa'),(86,'Myra','Munns','817-914-7518','mmunns@cox.net','2003-03-19','American Express'),(87,'Stephaine','Barfield','310-774-7643','stephaine@barfield.com','2003-05-19','Google Pay'),(88,'Lai','Gato','847-728-7286','lai.gato@gato.org','2003-07-19','Google Pay'),(89,'Stephen','Emigh','330-537-5358','stephen_emigh@hotmail.com','2003-09-18','Visa'),(90,'Tyra','Shields','215-255-1641','tshields@gmail.com','2003-11-18','Master Card'),(91,'Tammara','Wardrip','650-803-1936','twardrip@cox.net','2004-01-18','American Express'),(92,'Cory','Gibes','626-572-1096','cory.gibes@gmail.com','2004-03-19','Master Card'),(93,'Danica','Bruschke','254-782-8569','danica_bruschke@gmail.com','2004-05-19','Visa'),(94,'Wilda','Giguere','907-870-5536','wilda@cox.net','2004-07-19','Google Pay'),(95,'Elvera','Benimadho','408-703-8505','elvera.benimadho@cox.net','2004-09-18','Visa'),(96,'Carma','Vanheusen','510-503-7169','carma@cox.net','2004-11-18','Visa'),(97,'Malinda','Hochard','317-722-5066','malinda.hochard@yahoo.com','2005-01-18','Google Pay'),(98,'Natalie','Fern','307-704-8713','natalie.fern@hotmail.com','2005-03-20','American Express'),(99,'Lisha','Centini','703-235-3937','lisha@centini.org','2005-05-20','Master Card'),(100,'Arlene','Klusman','504-710-5840','arlene_klusman@gmail.com','2005-07-20','Master Card');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_location`
--

DROP TABLE IF EXISTS `customer_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_location` (
  `location_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  PRIMARY KEY (`location_id`,`customer_id`),
  KEY `fk_Location_has_Customer_Customer1_idx` (`customer_id`),
  KEY `fk_Location_has_Customer_Location1_idx` (`location_id`),
  CONSTRAINT `fk_Location_has_Customer_Customer1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Location_has_Customer_Location1` FOREIGN KEY (`location_id`) REFERENCES `location` (`location_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_location`
--

LOCK TABLES `customer_location` WRITE;
/*!40000 ALTER TABLE `customer_location` DISABLE KEYS */;
INSERT INTO `customer_location` VALUES (1,1),(2,2),(3,3),(4,4),(5,5),(6,6),(7,7),(8,8),(9,9),(10,10),(11,11),(12,12),(13,13),(14,14),(15,15),(16,16),(17,17),(18,18),(19,19),(20,20),(21,21),(22,22),(23,23),(24,24),(25,25),(26,26),(27,27),(28,28),(29,29),(30,30),(31,31),(32,32),(33,33),(34,34),(35,35),(36,36),(37,37),(38,38),(39,39),(40,40),(41,41),(42,42),(43,43),(44,44),(45,45),(46,46),(47,47),(48,48),(49,49),(50,50),(51,51),(52,52),(53,53),(54,54),(55,55),(56,56),(57,57),(58,58),(59,59),(60,60),(61,61),(62,62),(63,63),(64,64),(65,65),(66,66),(67,67),(68,68),(69,69),(70,70),(71,71),(72,72),(73,73),(74,74),(75,75),(76,76),(77,77),(78,78),(79,79),(80,80),(81,81),(82,82),(83,83),(84,84),(85,85),(86,86),(87,87),(88,88),(89,89),(90,90),(91,91),(92,92),(93,93),(94,94),(95,95),(96,96),(97,97),(98,98),(99,99),(100,100);
/*!40000 ALTER TABLE `customer_location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dish`
--

DROP TABLE IF EXISTS `dish`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dish` (
  `dish_id` int(11) NOT NULL,
  `dish_name` varchar(45) DEFAULT NULL,
  `description` text,
  `price` float DEFAULT NULL,
  PRIMARY KEY (`dish_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dish`
--

LOCK TABLES `dish` WRITE;
/*!40000 ALTER TABLE `dish` DISABLE KEYS */;
INSERT INTO `dish` VALUES (101,'Hamburger','Beef patty, Lettuce, Tomatoes, buns',5),(102,'Fish and Chips','Salted potato chips, catfish',7),(103,'Grilled Cheese','Cheese, butter, bread',3),(104,'Hot Dog',NULL,3),(105,'Ribs',NULL,12),(106,'Bacon Burger','Beef patty, bacon, lettuce, BBQ sauce',6),(107,'Fries','Potatoes',2.5),(108,'Sweet Potato Fries','Sweet potatoes',2.5),(201,'Taco - beef',NULL,3),(202,'Taco - pork',NULL,3),(203,'Taco - fish',NULL,3.5),(204,'Taco - steak',NULL,3.5),(205,'Burrito Steak',NULL,4),(206,'Burrito Chicken',NULL,3.5),(207,'Burrito Fish',NULL,3.5),(208,'Burrito Pork',NULL,3.5),(209,'Carne Asada',NULL,4),(210,'Carnitas',NULL,4),(211,'Nachos',NULL,3),(212,'Quesadilla',NULL,3),(213,'Quesadilla - chicken',NULL,4),(301,'Noodles - Chicken',NULL,4),(302,'Beef Broccoli',NULL,4),(303,'Pot Stickers','Pork',4),(304,'Sweet and Sour Pork',NULL,4),(305,'Fried Rice','Vegeterian',2),(306,'Pork fried rice','Pork',4),(307,'Curry Katsu',NULL,5),(308,'Chicken Katsu',NULL,5),(309,'Poke Bowl','Raw Fish',7),(310,'Bulgogi',NULL,7),(311,'Bulgogi Burrito',NULL,7),(312,'Roast Duck',NULL,10),(313,'Duck Burrito',NULL,8),(401,'Butter Chicken',NULL,12),(402,'Chicken tikka masala',NULL,11),(403,'Plain Naan',NULL,2),(404,'Butter Naan',NULL,2),(405,'Garlic Naan',NULL,2),(406,'Lachcha Parantha',NULL,4),(407,'Chicken Biryani',NULL,10),(408,'Mutton Biryani',NULL,11),(409,'Punjabi Chhole',NULL,9),(410,'Dal Makhani',NULL,8),(411,'Sarson da saag',NULL,10),(412,'Makki di roti',NULL,3),(501,'Soda Drink','Canned soda',2),(502,'Bottled Water','Cold watter in bottle',2),(503,'Craft Beer','Alcoholic beverage',7);
/*!40000 ALTER TABLE `dish` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `favorite_trucks`
--

DROP TABLE IF EXISTS `favorite_trucks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `favorite_trucks` (
  `customer_id` int(11) NOT NULL,
  `truck_id` int(11) NOT NULL,
  PRIMARY KEY (`customer_id`,`truck_id`),
  KEY `fk_Customer_has_Food_Truck_Food_Truck1_idx` (`truck_id`),
  KEY `fk_Customer_has_Food_Truck_Customer1_idx` (`customer_id`),
  CONSTRAINT `fk_Customer_has_Food_Truck_Customer1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Customer_has_Food_Truck_Food_Truck1` FOREIGN KEY (`truck_id`) REFERENCES `food_truck` (`truck_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favorite_trucks`
--

LOCK TABLES `favorite_trucks` WRITE;
/*!40000 ALTER TABLE `favorite_trucks` DISABLE KEYS */;
INSERT INTO `favorite_trucks` VALUES (2,1),(15,1),(28,1),(41,1),(54,1),(67,1),(80,1),(93,1),(3,2),(16,2),(29,2),(42,2),(55,2),(68,2),(81,2),(94,2),(4,3),(17,3),(30,3),(43,3),(56,3),(69,3),(82,3),(95,3),(5,4),(18,4),(31,4),(44,4),(57,4),(70,4),(83,4),(96,4),(6,5),(19,5),(32,5),(45,5),(58,5),(71,5),(84,5),(97,5),(7,6),(20,6),(33,6),(46,6),(59,6),(72,6),(85,6),(98,6),(1,7),(8,7),(14,7),(21,7),(27,7),(34,7),(40,7),(47,7),(53,7),(60,7),(66,7),(73,7),(79,7),(86,7),(92,7),(99,7),(9,8),(22,8),(35,8),(48,8),(61,8),(74,8),(87,8),(100,8),(10,9),(23,9),(36,9),(49,9),(62,9),(75,9),(88,9),(11,10),(24,10),(37,10),(50,10),(63,10),(76,10),(89,10),(12,11),(25,11),(38,11),(51,11),(64,11),(77,11),(90,11),(13,12),(26,12),(39,12),(52,12),(65,12),(78,12),(91,12);
/*!40000 ALTER TABLE `favorite_trucks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `food_truck`
--

DROP TABLE IF EXISTS `food_truck`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `food_truck` (
  `truck_id` int(11) NOT NULL AUTO_INCREMENT,
  `truck_name` varchar(45) NOT NULL,
  `truck_manager` varchar(45) DEFAULT NULL,
  `truck_type` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`truck_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `food_truck`
--

LOCK TABLES `food_truck` WRITE;
/*!40000 ALTER TABLE `food_truck` DISABLE KEYS */;
INSERT INTO `food_truck` VALUES (1,'El Tonayense','El Tonayense','Mexican'),(2,'Taco Guys','Taco Guys','Mexican'),(3,'Tacos El Gordo','Tacos El Gordo','Mexican'),(4,'Ko Ja Kitchen','Ko Ja Kitchen','Korean-Japanese'),(5,'The Chairman','The Chairman','American'),(6,'J Shack','J Shack','American'),(7,'Pluck','Pluck','Chinese'),(8,'Fins on the Hoof','Fins on the Hoof','Chinese'),(9,'Mayo and Mustard','Mayo and Mustard','American'),(10,'Biryani house','Biryani house','Indian'),(11,'Sher e punjab','Sher e punjab','Indian'),(12,'Curry up Now','Curry up Now','Indian');
/*!40000 ALTER TABLE `food_truck` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `food_truck_location`
--

DROP TABLE IF EXISTS `food_truck_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `food_truck_location` (
  `location_id` int(11) NOT NULL,
  `truck_id` int(11) NOT NULL,
  PRIMARY KEY (`location_id`,`truck_id`),
  KEY `fk_Location_has_Food_Truck_Food_Truck1_idx` (`truck_id`),
  KEY `fk_Location_has_Food_Truck_Location1_idx` (`location_id`),
  CONSTRAINT `fk_Location_has_Food_Truck_Food_Truck1` FOREIGN KEY (`truck_id`) REFERENCES `food_truck` (`truck_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Location_has_Food_Truck_Location1` FOREIGN KEY (`location_id`) REFERENCES `location` (`location_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `food_truck_location`
--

LOCK TABLES `food_truck_location` WRITE;
/*!40000 ALTER TABLE `food_truck_location` DISABLE KEYS */;
INSERT INTO `food_truck_location` VALUES (102,1),(103,2),(114,2),(121,2),(104,3),(126,3),(105,4),(120,4),(125,4),(106,5),(115,5),(107,6),(124,6),(108,7),(123,7),(109,8),(116,8),(110,9),(117,9),(111,10),(118,10),(112,11),(119,11),(113,12),(122,12);
/*!40000 ALTER TABLE `food_truck_location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `location` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `zip_code` int(11) DEFAULT NULL,
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=127 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location`
--

LOCK TABLES `location` WRITE;
/*!40000 ALTER TABLE `location` DISABLE KEYS */;
INSERT INTO `location` VALUES (1,95050),(2,95014),(3,95054),(4,94087),(5,94041),(6,95110),(7,95050),(8,95050),(9,95050),(10,95014),(11,95014),(12,94087),(13,94087),(14,94087),(15,94087),(16,94041),(17,94041),(18,95110),(19,94041),(20,95110),(21,95110),(22,95050),(23,95014),(24,95054),(25,94087),(26,94041),(27,95110),(28,95050),(29,95050),(30,95050),(31,95014),(32,95014),(33,94087),(34,94087),(35,94087),(36,94087),(37,94041),(38,94041),(39,95110),(40,94041),(41,95110),(42,95110),(43,95050),(44,95014),(45,95054),(46,94087),(47,94041),(48,95110),(49,95050),(50,95050),(51,95050),(52,95014),(53,95014),(54,94087),(55,94087),(56,94087),(57,94087),(58,94041),(59,94041),(60,95110),(61,94041),(62,95110),(63,95110),(64,94087),(65,94087),(66,94041),(67,94041),(68,95110),(69,94041),(70,94087),(71,94087),(72,94041),(73,94041),(74,95110),(75,94041),(76,95054),(77,95054),(78,94041),(79,95110),(80,94041),(81,95054),(82,94041),(83,95110),(84,94041),(85,95054),(86,95054),(87,94087),(88,94041),(89,95110),(90,95054),(91,94087),(92,94041),(93,95110),(94,94087),(95,94087),(96,94087),(97,94087),(98,94041),(99,94041),(100,94087),(101,94087),(102,94087),(103,94087),(104,94041),(105,94041),(106,95054),(107,94087),(108,94041),(109,95110),(110,95050),(111,95050),(112,95054),(113,94087),(114,94041),(115,95110),(116,95050),(117,95050),(118,95050),(119,95014),(120,95054),(121,94087),(122,94041),(123,95110),(124,95050),(125,94041),(126,95110);
/*!40000 ALTER TABLE `location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order` (
  `order_id` int(11) NOT NULL,
  `truck_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `dish_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`order_id`,`truck_id`,`customer_id`,`dish_id`),
  KEY `fk_Order_Details_Orders1_idx` (`order_id`),
  KEY `fk_Order_Details_Food_Truck1_idx` (`truck_id`),
  KEY `fk_Order_Details_Customer1_idx` (`customer_id`),
  KEY `fk_Order_Details_Dish1_idx` (`dish_id`),
  CONSTRAINT `fk_Order_Details_Customer1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Order_Details_Dish1` FOREIGN KEY (`dish_id`) REFERENCES `dish` (`dish_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Order_Details_Food_Truck1` FOREIGN KEY (`truck_id`) REFERENCES `food_truck` (`truck_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Order_Details_Orders1` FOREIGN KEY (`order_id`) REFERENCES `order_details` (`order_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order`
--

LOCK TABLES `order` WRITE;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
INSERT INTO `order` VALUES (12362,10,23,401,1),(12363,8,31,302,1),(12364,4,27,503,1),(12364,4,33,311,1),(12364,4,73,312,1),(12364,4,95,310,1),(12365,6,32,502,1),(12365,6,33,101,1),(12365,6,77,503,1),(12365,6,90,105,1),(12366,2,3,503,1),(12366,2,61,213,1),(12366,2,67,201,1),(12367,12,27,401,3),(12367,12,74,402,3),(12367,12,77,502,3),(12368,9,46,107,1),(12368,9,73,108,1),(12368,9,77,501,1),(12369,2,28,503,1),(12369,2,92,201,1),(12369,2,97,202,1),(12370,4,27,307,2),(12370,4,87,308,2),(12371,1,64,503,1),(12371,1,89,204,1),(12372,5,29,101,2),(12372,5,68,503,2),(12373,10,19,402,3),(12373,10,40,502,3),(12374,9,20,103,2),(12374,9,39,501,2),(12374,9,93,104,2),(12374,9,100,101,2),(12375,2,38,501,1),(12375,2,45,203,1),(12375,2,87,202,1),(12376,3,83,201,1),(12377,7,65,301,2),(12377,7,67,503,2),(12378,8,33,501,1),(12378,8,40,303,1),(12378,8,49,301,1),(12379,9,2,502,1),(12379,9,3,103,1),(12379,9,11,101,1),(12380,2,23,204,2),(12380,2,45,205,2),(12380,2,57,503,2),(12381,5,49,104,1),(12381,5,55,102,1),(12381,5,61,103,1),(12381,5,97,502,1),(12382,7,91,304,1),(12382,7,98,303,1),(12383,12,57,503,2),(12383,12,83,409,2),(12384,5,44,107,1),(12384,5,83,501,1),(12384,5,90,108,1),(12385,4,14,310,1),(12385,4,37,502,1),(12385,4,69,309,1),(12386,3,21,203,1),(12386,3,82,202,1),(12387,8,25,304,1),(12388,9,3,106,1),(12388,9,16,503,1),(12388,9,91,104,1),(12389,10,9,502,1),(12390,4,47,307,1),(12391,8,73,305,1),(12392,1,69,206,1),(12393,2,71,206,1),(12393,2,77,203,1),(12393,2,79,207,1),(12394,9,64,107,1),(12395,3,91,204,3),(12396,9,71,108,1),(12397,6,40,107,1),(12397,6,78,503,1),(12398,12,46,410,2),(12399,12,2,404,1),(12400,12,66,409,1),(12401,3,65,210,1),(12402,8,27,306,1),(12403,7,97,305,1),(12404,8,80,301,1),(12404,8,81,503,1),(12405,5,64,101,1),(12406,4,89,312,1),(12407,4,6,308,2),(12407,4,11,503,2),(12407,4,30,307,2),(12407,4,41,313,2),(12408,6,5,108,1),(12409,12,49,409,1),(12410,10,16,404,2),(12411,10,92,401,1),(12412,8,68,302,1),(12413,4,75,310,1),(12414,4,63,311,1),(12415,4,95,312,1),(12416,4,95,503,1),(12417,6,61,101,1),(12418,6,10,105,1),(12419,6,3,503,1),(12420,6,12,502,1),(12421,2,82,213,1),(12422,2,85,201,1),(12423,2,76,503,1),(12424,12,59,401,3),(12425,12,53,402,3),(12426,12,34,502,3),(12427,9,49,107,1),(12428,9,41,108,1),(12429,9,79,501,1),(12430,2,97,201,1),(12431,2,93,202,1),(12432,2,87,503,1),(12433,4,87,307,2),(12434,4,21,308,2),(12435,1,52,204,1),(12436,1,95,503,1),(12437,5,8,101,2),(12438,5,31,503,2),(12439,10,37,402,3),(12440,10,14,502,3),(12441,9,97,104,2),(12442,9,92,103,2),(12443,9,47,101,2),(12444,9,58,501,2),(12445,2,36,202,1),(12446,2,39,203,1),(12447,2,37,501,1),(12448,3,70,201,1),(12449,7,17,301,2),(12450,7,29,503,2),(12451,8,36,301,1),(12452,8,15,501,1),(12453,8,35,303,1),(12454,9,75,101,1),(12455,9,55,103,1),(12456,9,53,502,1),(12457,2,30,204,2),(12458,2,61,205,2),(12459,2,41,503,2),(12460,5,92,102,1),(12461,5,8,103,1),(12462,5,84,104,1),(12463,5,88,502,1),(12464,7,26,303,1),(12465,7,62,304,1),(12466,12,70,409,2),(12467,12,82,503,2),(12468,5,62,107,1),(12469,5,31,108,1),(12470,5,73,501,1),(12471,4,51,309,1),(12472,4,37,310,1),(12473,4,5,502,1),(12474,3,52,202,1),(12475,3,64,203,1),(12476,8,25,304,1),(12477,9,23,104,1),(12478,9,13,106,1),(12479,9,54,503,1),(12480,10,26,502,1),(12481,4,52,307,1),(12482,8,94,305,1),(12483,1,51,206,1),(12484,2,33,206,1),(12485,2,60,207,1),(12486,2,48,203,1),(12487,9,46,107,1),(12488,3,62,204,3),(12489,9,64,108,1),(12490,6,22,503,1),(12491,6,97,107,1),(12492,12,31,410,2),(12493,12,75,404,1),(12494,12,90,409,1),(12495,3,31,210,1),(12496,8,47,306,1),(12497,7,26,305,1),(12498,8,56,301,1),(12499,8,72,503,1),(12500,5,46,101,1),(12501,4,84,312,1),(12502,4,20,313,2),(12503,4,68,307,2),(12504,4,81,308,2),(12505,4,49,503,2),(12506,6,34,108,1),(12507,12,4,409,1),(12508,10,73,404,2),(12509,10,61,401,1),(12510,8,60,302,1),(12511,4,98,310,1),(12512,4,99,311,1),(12513,4,6,312,1),(12514,4,74,503,1),(12515,6,31,101,1),(12516,6,35,105,1),(12517,6,49,503,1),(12518,6,27,502,1),(12519,2,11,213,1),(12520,2,35,201,1),(12521,2,30,503,1),(12522,12,28,401,3),(12523,12,94,402,3),(12524,12,20,502,3),(12525,9,14,107,1),(12526,9,32,108,1),(12527,9,75,501,1),(12528,2,37,201,1),(12529,2,24,202,1),(12530,2,38,503,1),(12531,4,98,307,2),(12532,4,9,308,2),(12533,1,21,204,1),(12534,1,4,503,1),(12535,5,54,101,2),(12536,5,7,503,2),(12537,10,50,402,3),(12538,10,11,502,3),(12539,9,37,104,2),(12540,9,49,103,2),(12541,9,92,101,2),(12542,9,53,501,2),(12543,2,29,202,1),(12544,2,55,203,1),(12545,2,77,501,1),(12546,3,53,201,1),(12547,7,55,301,2),(12548,7,49,503,2),(12549,8,15,301,1),(12550,8,49,501,1),(12551,8,1,303,1),(12552,9,97,101,1),(12553,9,5,103,1),(12554,9,47,502,1),(12555,2,77,204,2),(12556,2,27,205,2),(12557,2,73,503,2),(12558,5,8,102,1),(12559,5,50,103,1),(12560,5,29,104,1),(12561,5,73,502,1),(12562,7,63,303,1),(12563,7,97,304,1),(12564,12,82,409,2),(12565,12,51,503,2),(12566,5,18,107,1),(12567,5,78,108,1),(12568,5,10,501,1),(12569,4,84,309,1),(12570,4,89,310,1),(12571,4,64,502,1),(12572,3,95,202,1),(12573,3,12,203,1),(12574,8,6,304,1),(12575,9,98,104,1),(12576,9,48,106,1),(12577,9,73,503,1),(12578,10,81,502,1),(12579,4,35,307,1),(12580,8,8,305,1),(12581,1,72,206,1),(12582,2,68,206,1),(12583,2,49,207,1),(12584,2,94,203,1),(12585,9,69,107,1),(12586,3,53,204,3),(12587,9,27,108,1),(12588,6,64,503,1),(12589,6,56,107,1),(12590,12,91,410,2),(12591,12,51,404,1),(12592,12,61,409,1),(12593,3,80,210,1),(12594,8,4,306,1),(12595,7,94,305,1),(12596,8,67,301,1),(12597,8,8,503,1),(12598,5,86,101,1),(12599,4,73,312,1),(12600,4,71,313,2),(12601,4,85,307,2),(12602,4,88,308,2),(12603,4,83,503,2),(12604,6,2,108,1),(12605,12,68,409,1),(12606,10,67,404,2);
/*!40000 ALTER TABLE `order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_details`
--

DROP TABLE IF EXISTS `order_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_details` (
  `order_id` int(11) NOT NULL,
  `order_date` datetime DEFAULT NULL,
  `order_status` varchar(45) DEFAULT NULL,
  `rating` float DEFAULT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_details`
--

LOCK TABLES `order_details` WRITE;
/*!40000 ALTER TABLE `order_details` DISABLE KEYS */;
INSERT INTO `order_details` VALUES (12362,'2018-05-18 11:03:00','Complete',10),(12363,'2018-05-18 11:03:00','Complete',10),(12364,'2018-05-18 13:10:00','Complete',9),(12365,'2018-05-19 11:03:00','Complete',8),(12366,'2018-05-19 12:03:00','Complete',7),(12367,'2018-05-19 12:03:00','Complete',2),(12368,'2018-05-19 12:03:00','Complete',5),(12369,'2018-05-19 12:03:00','Complete',4),(12370,'2018-05-19 12:03:00','Complete',6),(12371,'2018-05-19 12:03:00','Complete',1),(12372,'2018-05-19 12:03:00','Complete',2),(12373,'2018-05-19 12:03:00','Complete',4),(12374,'2018-05-19 12:03:00','Complete',2),(12375,'2018-05-19 12:03:00','Complete',8),(12376,'2018-05-19 12:03:00','Complete',7),(12377,'2018-05-19 13:10:00','Complete',8),(12378,'2018-05-19 17:20:00','Complete',8),(12379,'2018-05-20 11:03:00','Complete',8),(12380,'2018-05-20 12:03:00','Complete',5),(12381,'2018-05-20 12:03:00','Complete',5),(12382,'2018-05-20 12:03:00','Complete',7),(12383,'2018-05-20 12:03:00','Complete',7),(12384,'2018-05-20 12:03:00','Complete',7),(12385,'2018-05-20 12:15:00','Complete',8),(12386,'2018-05-20 12:15:00','Complete',10),(12387,'2018-05-20 12:15:00','Complete',10),(12388,'2018-05-20 12:15:00','Complete',10),(12389,'2018-05-20 12:15:00','Complete',9),(12390,'2018-05-20 12:15:00','Complete',9),(12391,'2018-05-20 12:15:00','Complete',10),(12392,'2018-05-20 12:15:00','Complete',9),(12393,'2018-05-20 13:10:00','Complete',8),(12394,'2018-05-20 13:10:00','Complete',7),(12395,'2018-05-20 13:10:00','Complete',10),(12396,'2018-05-20 17:20:00','Complete',8),(12397,'2018-05-20 17:20:00','Complete',7),(12398,'2018-05-21 11:03:00','Complete',9),(12399,'2018-05-21 11:03:00','Complete',7),(12400,'2018-05-21 11:03:00','Complete',9),(12401,'2018-05-21 12:03:00','Complete',8),(12402,'2018-05-21 12:03:00','Complete',7),(12403,'2018-05-21 12:03:00','Complete',10),(12404,'2018-05-21 12:03:00','Complete',10),(12405,'2018-05-21 12:03:00','Complete',9),(12406,'2018-05-21 12:03:00','Complete',10),(12407,'2018-05-21 12:03:00','Complete',9),(12408,'2018-05-21 12:03:00','Complete',7),(12409,'2018-05-21 12:15:00','Complete',6),(12410,'2018-05-21 12:15:00','Complete',6),(12411,'2018-05-21 12:15:00','Complete',10),(12412,'2018-05-21 12:15:00','Complete',10),(12413,'2018-05-21 12:15:00','Complete',9),(12414,'2018-05-21 12:15:00','Complete',9),(12415,'2018-05-21 12:15:00','Complete',9),(12416,'2018-05-21 12:15:00','Complete',9),(12417,'2018-05-21 12:15:00','Complete',8),(12418,'2018-05-21 12:15:00','Complete',8),(12419,'2018-05-21 12:15:00','Complete',8),(12420,'2018-05-21 12:15:00','Complete',8),(12421,'2018-05-21 12:15:00','Complete',7),(12422,'2018-05-21 12:15:00','Complete',7),(12423,'2018-05-21 12:15:00','Complete',7),(12424,'2018-05-21 13:10:00','Complete',2),(12425,'2018-05-21 13:10:00','Complete',2),(12426,'2018-05-21 13:10:00','Complete',2),(12427,'2018-05-21 17:20:00','Complete',5),(12428,'2018-05-21 17:20:00','Complete',5),(12429,'2018-05-21 17:20:00','Complete',5),(12430,'2018-05-22 11:03:00','Complete',4),(12431,'2018-05-22 11:03:00','Complete',4),(12432,'2018-05-22 11:03:00','Complete',4),(12433,'2018-05-22 12:03:00','Complete',6),(12434,'2018-05-22 12:03:00','Complete',6),(12435,'2018-05-22 12:03:00','Complete',1),(12436,'2018-05-22 12:03:00','Complete',1),(12437,'2018-05-22 12:03:00','Complete',2),(12438,'2018-05-22 12:03:00','Complete',2),(12439,'2018-05-22 12:03:00','Complete',4),(12440,'2018-05-22 12:03:00','Complete',4),(12441,'2018-05-22 12:03:00','Complete',2),(12442,'2018-05-22 12:03:00','Complete',2),(12443,'2018-05-22 12:03:00','Complete',2),(12444,'2018-05-22 12:03:00','Complete',2),(12445,'2018-05-22 12:15:00','Complete',8),(12446,'2018-05-22 12:15:00','Complete',8),(12447,'2018-05-22 12:15:00','Complete',8),(12448,'2018-05-22 13:10:00','Complete',7),(12449,'2018-05-22 13:10:00','Complete',8),(12450,'2018-05-22 13:10:00','Complete',8),(12451,'2018-05-22 17:20:00','Complete',8),(12452,'2018-05-22 17:20:00','Complete',8),(12453,'2018-05-22 17:20:00','Complete',8),(12454,'2018-05-23 11:03:00','Complete',8),(12455,'2018-05-23 11:03:00','Complete',8),(12456,'2018-05-23 11:03:00','Complete',8),(12457,'2018-05-23 11:40:00','Complete',5),(12458,'2018-05-23 11:40:00','Complete',5),(12459,'2018-05-23 11:40:00','Complete',5),(12460,'2018-05-23 12:03:00','Complete',5),(12461,'2018-05-23 12:03:00','Complete',5),(12462,'2018-05-23 12:03:00','Complete',5),(12463,'2018-05-23 12:03:00','Complete',5),(12464,'2018-05-23 12:03:00','Complete',7),(12465,'2018-05-23 12:03:00','Complete',7),(12466,'2018-05-23 12:03:00','Complete',7),(12467,'2018-05-23 12:03:00','Complete',7),(12468,'2018-05-23 12:03:00','Complete',7),(12469,'2018-05-23 12:03:00','Complete',7),(12470,'2018-05-23 12:03:00','Complete',7),(12471,'2018-05-23 12:03:00','Complete',8),(12472,'2018-05-23 12:15:00','Complete',8),(12473,'2018-05-23 12:15:00','Complete',8),(12474,'2018-05-23 12:15:00','Complete',10),(12475,'2018-05-23 13:10:00','Complete',10),(12476,'2018-05-23 13:10:00','Complete',10),(12477,'2018-05-23 13:10:00','Complete',10),(12478,'2018-05-23 17:20:00','Complete',10),(12479,'2018-05-23 17:20:00','Complete',10),(12480,'2018-05-23 17:20:00','Complete',9),(12481,'2018-05-24 11:03:00','Complete',9),(12482,'2018-05-24 11:03:00','Complete',10),(12483,'2018-05-24 11:03:00','Complete',9),(12484,'2018-05-24 11:40:00','Complete',8),(12485,'2018-05-24 11:40:00','Complete',8),(12486,'2018-05-24 11:40:00','Complete',8),(12487,'2018-05-24 13:10:00','Complete',7),(12488,'2018-05-24 13:10:00','Complete',10),(12489,'2018-05-24 13:10:00','Complete',8),(12490,'2018-05-24 17:20:00','Complete',7),(12491,'2018-05-24 17:20:00','Complete',7),(12492,'2018-05-24 17:20:00','Complete',9),(12493,'2018-05-25 11:03:00','Complete',7),(12494,'2018-05-25 11:03:00','Complete',9),(12495,'2018-05-25 11:03:00','Complete',8),(12496,'2018-05-25 11:40:00','Complete',7),(12497,'2018-05-25 11:40:00','Complete',10),(12498,'2018-05-25 11:40:00','Complete',10),(12499,'2018-05-25 13:10:00','Complete',10),(12500,'2018-05-25 13:10:00','Complete',9),(12501,'2018-05-25 13:10:00','Complete',10),(12502,'2018-05-25 17:20:00','Complete',9),(12503,'2018-05-25 17:20:00','Complete',9),(12504,'2018-05-25 17:20:00','Complete',9),(12505,'2018-05-26 11:03:00','Complete',9),(12506,'2018-05-26 11:03:00','Complete',7),(12507,'2018-05-26 11:03:00','Complete',6),(12508,'2018-05-26 11:40:00','Complete',6),(12509,'2018-05-26 11:40:00','Complete',10),(12510,'2018-05-26 11:40:00','Complete',10),(12511,'2018-05-26 13:10:00','Complete',9),(12512,'2018-05-26 13:10:00','Complete',9),(12513,'2018-05-26 13:10:00','Complete',9),(12514,'2018-05-26 17:20:00','Complete',9),(12515,'2018-05-26 17:20:00','Complete',8),(12516,'2018-05-26 17:20:00','Complete',8),(12517,'2018-05-27 11:03:00','Complete',8),(12518,'2018-05-27 11:03:00','Complete',8),(12519,'2018-05-27 11:03:00','Complete',7),(12520,'2018-05-27 11:40:00','Complete',7),(12521,'2018-05-27 11:40:00','Complete',7),(12522,'2018-05-27 11:40:00','Complete',2),(12523,'2018-05-27 13:10:00','Complete',2),(12524,'2018-05-27 13:10:00','Complete',2),(12525,'2018-05-27 13:10:00','Complete',5),(12526,'2018-05-27 17:20:00','Complete',5),(12527,'2018-05-27 17:20:00','Complete',5),(12528,'2018-05-27 17:20:00','Complete',4),(12529,'2018-05-28 11:03:00','Complete',4),(12530,'2018-05-28 11:03:00','Complete',4),(12531,'2018-05-28 11:03:00','Complete',6),(12532,'2018-05-28 11:40:00','Complete',6),(12533,'2018-05-28 11:40:00','Complete',1),(12534,'2018-05-28 11:40:00','Complete',1),(12535,'2018-05-28 13:10:00','Complete',2),(12536,'2018-05-28 13:10:00','Complete',2),(12537,'2018-05-28 13:10:00','Complete',4),(12538,'2018-05-28 17:20:00','Complete',4),(12539,'2018-05-28 17:20:00','Complete',2),(12540,'2018-05-28 17:20:00','Complete',2),(12541,'2018-05-29 11:03:00','Complete',2),(12542,'2018-05-29 11:03:00','Complete',2),(12543,'2018-05-29 11:03:00','Complete',8),(12544,'2018-05-29 11:40:00','Complete',8),(12545,'2018-05-29 11:40:00','Complete',8),(12546,'2018-05-29 11:40:00','Complete',7),(12547,'2018-05-29 13:10:00','Complete',8),(12548,'2018-05-29 13:10:00','Complete',8),(12549,'2018-05-29 13:10:00','Complete',8),(12550,'2018-05-29 17:20:00','Complete',8),(12551,'2018-05-29 17:20:00','Complete',8),(12552,'2018-05-29 17:20:00','Complete',8),(12553,'2018-05-30 11:03:00','Complete',8),(12554,'2018-05-30 11:03:00','Complete',8),(12555,'2018-05-30 11:03:00','Complete',5),(12556,'2018-05-30 11:40:00','Complete',5),(12557,'2018-05-30 11:40:00','Complete',5),(12558,'2018-05-30 11:40:00','Complete',5),(12559,'2018-05-30 13:10:00','Complete',5),(12560,'2018-05-30 13:10:00','Complete',5),(12561,'2018-05-30 13:10:00','Complete',5),(12562,'2018-05-30 17:20:00','Complete',7),(12563,'2018-05-30 17:20:00','Complete',7),(12564,'2018-05-30 17:20:00','Complete',7),(12565,'2018-05-31 11:03:00','Complete',7),(12566,'2018-05-31 11:03:00','Complete',7),(12567,'2018-05-31 11:03:00','Complete',7),(12568,'2018-05-31 11:40:00','Complete',7),(12569,'2018-05-31 11:40:00','Awaiting Pickup',8),(12570,'2018-05-31 11:40:00','Awaiting Pickup',8),(12571,'2018-05-31 13:10:00','Awaiting Pickup',8),(12572,'2018-05-31 13:10:00','Awaiting Pickup',10),(12573,'2018-05-31 13:10:00','Awaiting Pickup',10),(12574,'2018-05-31 17:20:00','Awaiting Pickup',10),(12575,'2018-05-31 17:20:00','Awaiting Pickup',10),(12576,'2018-05-31 17:20:00','Awaiting Pickup',10),(12577,'2018-06-01 11:03:00','Awaiting Pickup',10),(12578,'2018-06-01 11:03:00','Awaiting Pickup',9),(12579,'2018-06-01 11:03:00','Awaiting Pickup',9),(12580,'2018-06-01 17:20:00','Awaiting Pickup',10),(12581,'2018-06-01 17:20:00','Awaiting Pickup',9),(12582,'2018-06-01 17:20:00','Awaiting Pickup',8),(12583,'2018-06-02 11:03:00','Awaiting Pickup',8),(12584,'2018-06-02 11:03:00','Awaiting Pickup',8),(12585,'2018-06-02 11:03:00','Awaiting Pickup',7),(12586,'2018-06-02 17:20:00','Awaiting Pickup',10),(12587,'2018-06-02 17:20:00','Awaiting Pickup',8),(12588,'2018-06-02 17:20:00','In Progress',7),(12589,'2018-06-03 11:03:00','In Progress',7),(12590,'2018-06-03 11:03:00','In Progress',9),(12591,'2018-06-03 11:03:00','In Progress',7),(12592,'2018-06-03 17:20:00','In Progress',9),(12593,'2018-06-03 17:20:00','In Progress',8),(12594,'2018-06-03 17:20:00','In Progress',7),(12595,'2018-06-04 11:03:00','Order Received',10),(12596,'2018-06-04 11:03:00','Order Received',10),(12597,'2018-06-04 11:03:00','Order Received',10),(12598,'2018-06-04 17:20:00','Order Received',9),(12599,'2018-06-04 17:20:00','Order Received',10),(12600,'2018-06-04 17:20:00','Order Received',9),(12601,'2018-06-05 11:03:00','Order Received',9),(12602,'2018-06-05 11:03:00','Order Received',9),(12603,'2018-06-05 11:03:00','Order Received',9),(12604,'2018-06-05 17:20:00','Order Received',7),(12605,'2018-06-05 17:20:00','Order Received',6),(12606,'2018-06-05 17:20:00','Order Received',6);
/*!40000 ALTER TABLE `order_details` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-05-23 22:28:52
